package com.forexsessionclock.madagascar

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.Instant

object AlarmScheduler {
    const val ACTION = "com.forexsessionclock.madagascar.SESSION_ALARM"
    const val EXTRA_TITLE = "title"
    const val EXTRA_TEXT = "text"

    fun schedule(context: Context) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = Instant.now()
        var id = 1000
        for (day in 0..10) {
            val base = now.plusSeconds(day * 86400L)
            // Rechercher les événements à venir dans la journée, y compris les changements DST.
            for (session in MarketSessions.sessions) {
                val localDate = base.atZone(session.zone).toLocalDate()
                if (localDate.dayOfWeek.value >= 6) continue
                val open = localDate.atTime(session.open).atZone(session.zone).toInstant()
                val close = localDate.atTime(session.close).atZone(session.zone).toInstant()
                for ((time, label, detail) in listOf(
                    Triple(open.minusSeconds(15*60L), "Dans 15 minutes", "Ouverture de ${session.name} dans 15 minutes"),
                    Triple(open, "Ouverture", "La session ${session.name} ouvre maintenant"),
                    Triple(close, "Fermeture", "La session ${session.name} ferme maintenant")
                )) {
                    if (time.isAfter(now)) {
                        val intent = Intent(context, SessionAlarmReceiver::class.java).apply {
                            action = ACTION
                            putExtra(EXTRA_TITLE, "$label · ${session.name}")
                            putExtra(EXTRA_TEXT, detail)
                        }
                        val pi = PendingIntent.getBroadcast(context, id++, intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms()) {
                                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time.toEpochMilli(), pi)
                            } else {
                                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time.toEpochMilli(), pi)
                            }
                        } else manager.setExact(AlarmManager.RTC_WAKEUP, time.toEpochMilli(), pi)
                    }
                }
            }
        }
    }
}
