package com.forexsessionclock.madagascar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class SessionAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = "forex_sessions"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channel, "Alertes de sessions", NotificationManager.IMPORTANCE_HIGH))
        }
        val title = intent.getStringExtra(AlarmScheduler.EXTRA_TITLE) ?: "Alerte Forex"
        val body = intent.getStringExtra(AlarmScheduler.EXTRA_TEXT) ?: "Événement de session"
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, channel) else Notification.Builder(context)
        val notification = builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body).setAutoCancel(true).build()
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
        // Maintient une fenêtre glissante d’alarmes au-delà des 11 prochains jours.
        AlarmScheduler.schedule(context)
    }
}
