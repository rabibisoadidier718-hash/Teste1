package com.forexsessionclock.madagascar

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import java.time.Instant
import java.time.Duration
import java.time.format.DateTimeFormatter

class SessionWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }
    override fun onReceive(context: Context, intent: android.content.Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.forexsessionclock.madagascar.WIDGET_REFRESH") updateAll(context)
    }
    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, SessionWidgetProvider::class.java))
            ids.forEach { update(context, manager, it) }
        }
        private fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val now = Instant.now()
            val active = MarketSessions.active(now)
            val next = MarketSessions.nextOpening(now)
            val remaining = Duration.between(now, next.instant)
            val hours = remaining.toHours()
            val mins = remaining.toMinutes() % 60
            val views = RemoteViews(context.packageName, R.layout.session_widget)
            views.setTextViewText(R.id.widget_active,
                if (active.isEmpty()) "MARCHÉ FERMÉ" else active.joinToString(" + ") { it.name.uppercase() })
            views.setTextViewText(R.id.widget_clock, MarketSessions.mdg(now) + " · Madagascar")
            views.setTextViewText(R.id.widget_next, "Prochaine : ${next.session.name} dans ${hours}h ${mins}min")
            manager.updateAppWidget(id, views)
        }
    }
}
