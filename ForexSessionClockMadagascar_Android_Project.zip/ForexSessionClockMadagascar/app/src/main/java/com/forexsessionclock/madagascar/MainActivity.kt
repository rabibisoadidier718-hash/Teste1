package com.forexsessionclock.madagascar

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.time.Instant
import java.time.Duration
import java.util.Timer
import kotlin.concurrent.timerTask

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private var timer: Timer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 24, 39)
        window.navigationBarColor = Color.rgb(18, 24, 39)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        buildUi()
        AlarmScheduler.schedule(this)
        SessionWidgetProvider.updateAll(this)
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(18, 24, 39))
        }
        scroll.addView(content)
        setContentView(scroll)

        addText("FOREX SESSION CLOCK", 23, Color.WHITE, true)
        addText("Horloge des marchés · Heure de Madagascar (UTC+3)", 13, Color.LTGRAY)
        addText(" ", 8, Color.WHITE)
        val clock = TextView(this).apply {
            textSize = 30f; setTextColor(Color.rgb(105,214,165)); gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        content.addView(clock)
        val status = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        content.addView(status)
        val nextView = TextView(this).apply {
            textSize = 15f; setTextColor(Color.rgb(197,206,224)); gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        content.addView(nextView)

        addText("SESSIONS MONDIALES", 16, Color.WHITE, true)
        MarketSessions.sessions.forEach { s ->
            val row = TextView(this).apply {
                textSize = 16f; setTextColor(Color.WHITE); setPadding(14, 14, 14, 14)
                setBackgroundColor(Color.rgb(31, 41, 59))
            }
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
            row.tag = s.name
        }
        val alarm = Button(this).apply {
            text = "Réactiver / reprogrammer les alarmes"
            setOnClickListener {
                AlarmScheduler.schedule(this@MainActivity)
                SessionWidgetProvider.updateAll(this@MainActivity)
                Toast.makeText(this@MainActivity, "Alarmes programmées (15 min avant, ouverture et fermeture).", Toast.LENGTH_LONG).show()
            }
        }
        content.addView(alarm)
        addText("Widget : maintiens ton doigt sur l'écran d'accueil → Widgets → Forex Session Clock.", 13, Color.LTGRAY)
        timer = Timer()
        timer?.scheduleAtFixedRate(timerTask { runOnUiThread {
            val now = Instant.now()
            clock.text = MarketSessions.mdg(now)
            val active = MarketSessions.active(now)
            status.text = if (active.isEmpty()) "Aucune session ouverte" else "SESSION ACTIVE : " + active.joinToString(" + ") { it.name }
            val next = MarketSessions.nextOpening(now)
            val d = Duration.between(now, next.instant)
            nextView.text = "Prochaine ouverture : ${next.session.name} dans ${d.toHours()} h ${d.toMinutes()%60} min"
            for (i in 0 until content.childCount) {
                val v = content.getChildAt(i)
                if (v is TextView && v.tag is String) {
                    val s = MarketSessions.sessions.first { it.name == v.tag }
                    val opened = MarketSessions.isOpen(s, now)
                    v.text = "${s.name}   ·   ${if (opened) "OUVERTE" else "fermée"}"
                    v.setTextColor(if (opened) Color.rgb(105,214,165) else Color.LTGRAY)
                }
            }
            SessionWidgetProvider.updateAll(this@MainActivity)
        } }, 0, 30_000)
    }

    private fun addText(value: String, size: Int, color: Int, bold: Boolean = false) {
        val t = TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        }
        content.addView(t)
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
