package com.forexsessionclock.madagascar

import java.time.*
import java.time.format.DateTimeFormatter

object MarketSessions {
    val madagascar: ZoneId = ZoneId.of("Africa/Antananarivo")
    data class Session(val name: String, val zone: ZoneId, val open: LocalTime, val close: LocalTime, val color: String)
    data class Event(val session: Session, val opening: Boolean, val instant: Instant)

    // Horaires indicatifs de séance locale; Londres/New York/Sydney suivent automatiquement l'heure d'été locale.
    val sessions = listOf(
        Session("Sydney", ZoneId.of("Australia/Sydney"), LocalTime.of(8,0), LocalTime.of(17,0), "#56B4E9"),
        Session("Tokyo", ZoneId.of("Asia/Tokyo"), LocalTime.of(9,0), LocalTime.of(18,0), "#E6B84A"),
        Session("Londres", ZoneId.of("Europe/London"), LocalTime.of(8,0), LocalTime.of(17,0), "#69D6A5"),
        Session("New York", ZoneId.of("America/New_York"), LocalTime.of(8,0), LocalTime.of(17,0), "#C28BFA")
    )

    fun isOpen(session: Session, instant: Instant): Boolean {
        val local = instant.atZone(session.zone)
        val day = local.dayOfWeek.value
        if (day >= 6) return false
        val t = local.toLocalTime()
        return !t.isBefore(session.open) && t.isBefore(session.close)
    }

    fun active(instant: Instant): List<Session> = sessions.filter { isOpen(it, instant) }

    fun nextEvent(after: Instant): Event {
        val candidates = mutableListOf<Event>()
        for (offset in 0..10) {
            val date = after.atZone(madagascar).toLocalDate().plusDays(offset)
            for (s in sessions) {
                val localDate = date.atStartOfDay(s.zone).toLocalDate()
                if (localDate.dayOfWeek.value >= 6) continue
                val open = localDate.atTime(s.open).atZone(s.zone).toInstant()
                val close = localDate.atTime(s.close).atZone(s.zone).toInstant()
                if (open.isAfter(after)) candidates.add(Event(s, true, open))
                if (close.isAfter(after)) candidates.add(Event(s, false, close))
            }
        }
        return candidates.minByOrNull { it.instant } ?: Event(sessions[1], true, after.plusSeconds(3600))
    }

    fun nextOpening(after: Instant): Event {
        val events = mutableListOf<Event>()
        for (offset in 0..10) {
            val date = after.atZone(madagascar).toLocalDate().plusDays(offset)
            for (s in sessions) {
                val d = date.atStartOfDay(s.zone).toLocalDate()
                if (d.dayOfWeek.value >= 6) continue
                val instant = d.atTime(s.open).atZone(s.zone).toInstant()
                if (instant.isAfter(after)) events.add(Event(s, true, instant))
            }
        }
        return events.minByOrNull { it.instant } ?: nextEvent(after)
    }

    fun label(instant: Instant): String {
        val current = active(instant)
        return if (current.isEmpty()) "Aucune session ouverte" else current.joinToString(" + ") { it.name }
    }

    fun mdg(instant: Instant): String = DateTimeFormatter.ofPattern("EEE dd MMM · HH:mm:ss")
        .withLocale(java.util.Locale.FRENCH).format(instant.atZone(madagascar))
}
