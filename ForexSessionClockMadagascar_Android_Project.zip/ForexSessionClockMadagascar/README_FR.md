# Forex Session Clock Madagascar — projet Android

Application Android hors ligne, interface française, fuseau de référence `Africa/Antananarivo` (UTC+3).

## Fonctions incluses dans le code
- Sessions Sydney, Tokyo, Londres et New York.
- Calcul des heures avec les fuseaux IANA : les changements d'heure saisonniers de Londres, New York et Sydney sont pris en compte.
- Indication des sessions ouvertes simultanément.
- Heure locale de Madagascar et compte à rebours vers la prochaine ouverture.
- Alarmes locales : 15 minutes avant l'ouverture, à l'ouverture et à la fermeture.
- Widget d'écran d'accueil affichant session active, heure de Madagascar et prochaine session.
- Reprogrammation des alarmes après redémarrage.

## Horaires utilisés
Horaires de référence indicatifs en heure locale de chaque place : Sydney 08:00–17:00, Tokyo 09:00–18:00, Londres 08:00–17:00, New York 08:00–17:00, du lundi au vendredi. Les horaires de Forex sont des conventions de marché, pas une ouverture centralisée unique. Les jours fériés et fermetures exceptionnelles ne sont pas intégrés.

## Construire l'APK
1. Ouvrir ce dossier dans Android Studio (version récente).
2. Laisser Gradle synchroniser le plugin Android.
3. Choisir `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. APK debug : `app/build/outputs/apk/debug/app-debug.apk`.

## Installation et autorisations
- Installer l'APK sur Android.
- Autoriser les notifications.
- Sur Android 12+, autoriser les alarmes exactes si le système le demande. Si l'autorisation n'est pas accordée, Android peut retarder certaines alarmes.
- Ajouter le widget depuis l'écran d'accueil : appui long > Widgets > Forex Session Clock.

## Limites et transparence
- L'application fonctionne sans Internet et ne fournit aucune donnée de prix ou signal de trading.
- Les notifications exactes dépendent des restrictions de batterie et des autorisations Android du téléphone.
- Le widget système se rafraîchit périodiquement; Android peut retarder ses mises à jour selon l'économie d'énergie.
- Ce projet source n'est pas un APK précompilé. Il doit être compilé et testé sur un appareil Android avant usage quotidien.
